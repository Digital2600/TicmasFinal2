package com.curso.android.app.practica.ticmasfinal2.model



data class ComparisonResult(val isEqual: Boolean)




