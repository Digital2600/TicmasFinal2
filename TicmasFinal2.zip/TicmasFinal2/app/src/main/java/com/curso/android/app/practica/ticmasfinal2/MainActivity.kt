package com.curso.android.app.practica.ticmasfinal2

import android.app.Activity

class MainActivity : Activity()